namespace EazFixer {
    internal class Flags
    {
        public static string InFile;
        public static string OutFile;

        public static bool   KeepTypes;
        public static bool   VirtFix;
    }
}
